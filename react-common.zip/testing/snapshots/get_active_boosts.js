
export default JSON.parse(`[
  {
    "season": null,
    "percent_bonus": 20,
    "boost_id": "19322261",
    "duration": 0,
    "duration_type": "unlimited",
    "modifier_type": "currency"
  }
]`);
